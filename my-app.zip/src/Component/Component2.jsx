import React from 'react'

function Component2() {
    return (
        <div>
            
            <h2>Component2</h2>
        </div>
    )
}

export default Component2
